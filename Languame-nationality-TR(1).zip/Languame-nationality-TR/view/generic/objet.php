<?php
echo $objet;
?>