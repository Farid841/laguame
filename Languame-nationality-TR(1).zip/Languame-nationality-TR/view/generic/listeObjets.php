<div style="display: flex; justify-content: center; margin-top: 20px;">
    <div style="background-color: #AAAAAA; width: 80%; align-self: center; border: 1px solid black; border-radius: 15px; padding: 10px;">
        <?php
        foreach ($tableau as $ligne) {
            echo $ligne;
        }
        ?>
    </div>
</div>