<?php

//Route::get('/api/, [controllerHome::class, 'index']);