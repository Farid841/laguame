<?php

require_once("model/reponse.php");
require_once("controller/controllerObjet.php");

class controllerReponse extends controllerObjet
{
    protected static $objet = "Reponse";
    protected static $cle = "id_alignement";
}
