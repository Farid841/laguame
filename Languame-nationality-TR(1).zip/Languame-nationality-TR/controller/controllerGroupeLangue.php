<?php

require_once("model/groupeLangue.php");
require_once("controller/controllerObjet.php");

class controllerGroupeLangue extends controllerObjet
{
    protected static $objet = "groupeLangue";
    protected static $cle = "id_groupeLangue";
}
