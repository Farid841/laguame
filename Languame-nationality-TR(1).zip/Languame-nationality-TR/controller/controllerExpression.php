<?php

require_once("model/expression.php");
require_once("controller/controllerObjet.php");

class controllerExpression extends controllerObjet
{
    protected static $objet = "Expression";
    protected static $cle = "id_expression";
}
