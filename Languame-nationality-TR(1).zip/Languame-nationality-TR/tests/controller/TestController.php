<?php

namespace controller;

class TestController
{
    public function index()
    {
        return 'Hello World!';
    }

    public function secondPage()
    {
        return 'This is the second page!';
    }
}